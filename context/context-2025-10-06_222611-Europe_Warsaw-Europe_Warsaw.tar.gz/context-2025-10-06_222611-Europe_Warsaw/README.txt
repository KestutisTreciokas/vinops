Snapshot:       /root/work/vinops.restore/context/context-2025-10-06_222611-Europe_Warsaw
Archive:        /root/work/vinops.restore/context/context-2025-10-06_222611-Europe_Warsaw.tar.gz
Repo:           /root/work/vinops.restore
Host (optional):<none>
Logs tail:      400
Time (local):   Mon Oct  6 11:26:11 PM MSK 2025
Time (Europe/Warsaw): Mon Oct  6 10:26:11 PM CEST 2025
