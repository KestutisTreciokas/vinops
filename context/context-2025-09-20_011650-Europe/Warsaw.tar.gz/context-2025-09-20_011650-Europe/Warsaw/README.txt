Vinops read-only snapshot
- Repo   : /root/work/vinops.restore
- Out    : /root/work/vinops.restore/context/context-2025-09-20_011650-Europe/Warsaw
- Time   : local=2025-09-20 02:16:50 +0300 | Europe/Warsaw=2025-09-20 01:16:50 CEST

This folder is safe to share. Secrets were best-effort masked.
