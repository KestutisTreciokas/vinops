Vinops read-only snapshot
- Repo   : /root/work/vinops.restore
- Out    : /root/work/vinops.restore/context/context-2025-09-20_011445-Europe/Warsaw
- Time   : local=2025-09-20 02:14:45 +0300 | Europe/Warsaw=2025-09-20 01:14:45 CEST

This folder is safe to share. Secrets were best-effort masked.
