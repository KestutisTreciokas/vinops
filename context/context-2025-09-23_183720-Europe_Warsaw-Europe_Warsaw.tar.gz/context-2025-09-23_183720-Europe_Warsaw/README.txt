Snapshot:       /root/work/vinops.restore/context/context-2025-09-23_183720-Europe_Warsaw
Archive:        /root/work/vinops.restore/context/context-2025-09-23_183720-Europe_Warsaw.tar.gz
Repo:           /root/work/vinops.restore
Host (optional):https://vinops.online
Logs tail:      400
Time (local):   Tue Sep 23 07:37:20 PM MSK 2025
Time (Europe/Warsaw): Tue Sep 23 06:37:20 PM CEST 2025
