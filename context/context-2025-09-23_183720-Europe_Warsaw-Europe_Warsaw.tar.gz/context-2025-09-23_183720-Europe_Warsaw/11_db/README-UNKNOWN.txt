UNKNOWN (no PG* env for psql). HowTo: export PGHOST/PGUSER/PGDATABASE/PGSSLMODE=verify-full PGSSLROOTCERT=/etc/vinops/pg/ca.crt
