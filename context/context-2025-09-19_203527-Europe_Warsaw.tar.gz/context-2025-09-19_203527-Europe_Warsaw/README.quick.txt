Быстрые заметки:
- Compose проект: <auto or unknown>
- Compose набор файлов: -f /root/work/vinops.restore/docker-compose.prod.yml -f /root/work/vinops.restore/docker-compose.db.yml -f /root/work/vinops.restore/docker-compose.hostfix.yml -f /root/work/vinops.restore/docker-compose.health.yml -f /root/work/vinops.restore/docker-compose.yml
- Публичный HOST для HTTP/SEO: https://vinops.online
